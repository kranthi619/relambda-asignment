# Three-Tier Web Application Automation

## Overview
This project automates the deployment and configuration of a three-tier web application infrastructure using Vagrant and Ansible. The infrastructure includes Nginx, HAProxy, and MySQL as the three tiers.

## Prerequisites
- Vagrant installed on your machine.
- Ansible installed on your machine.
- Either the Ubuntu Trusty64 or CentOS 6.5 x64 Vagrant boxes.

## Directory Structure
/three-tier-web-app
|-- Vagrantfile
|-- ansible/
| |-- playbook.yml
| |-- roles/
| |-- nginx/
| |-- tasks/
| |-- main.yml
| |-- templates/
| |-- nginx.conf.j2
| |-- haproxy/
| |-- tasks/
| |-- main.yml
| |-- templates/
| |-- haproxy.cfg.j2
| |-- mysql/
| |-- tasks/
| |-- main.yml
| |-- templates/
| |-- my.cnf.j2
|-- README.md

1. Update Vagrantfile
Open Vagrantfile and customize the VM configurations

2.Run Vagrant to Create VMs
  $vagrant up

3.Run Ansible Playbook
  $ansible-playbook -i vagrant_ansible_inventory ansible/playbook.yml

4.Accessing the VMs
 $vagrant ssh VM

5.Customizing Configurations
Customize Nginx configurations in ansible/roles/nginx/templates/nginx.conf.j2.
Customize HAProxy configurations in ansible/roles/haproxy/templates/haproxy.cfg.j2.
Customize MySQL configurations in ansible/roles/mysql/templates/my.cnf.j2.

6.Restart Services
  $vagrant provision




